import React, { useState } from "react";
import AuthModal from "./AuthModal";
import "./HomePage.css";

function HomePage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState("login");

  const openModal = (type) => {
    setModalType(type);
    setIsModalOpen(true);
  };

  return (
    <div className="homepage">
      <h1>Smart Classroom</h1>
      <div className="button-group">
        <button onClick={() => openModal("login")}>Login</button>
        <button onClick={() => openModal("signup")}>Signup</button>
      </div>
      {isModalOpen && (
        <AuthModal type={modalType} onClose={() => setIsModalOpen(false)} />
      )}
    </div>
  );
}

export default HomePage;
